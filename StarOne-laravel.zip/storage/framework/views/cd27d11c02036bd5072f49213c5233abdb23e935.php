

<?php $__env->startSection('title', 'All Games | PT StarOne'); ?>

<?php $__env->startSection('content'); ?>
    <!-- GAME CONTENT -->
    <div class="container">
        <h3><i class="uil uil-basketball me-1"></i> All Games</h3>
        <hr>
        <div class="row">
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-4">
                    <div class="col-md-12 bg-light game-item">
                        <span class="title"><?php echo e($game->judul); ?></span>
                        <span class="publisher badge bg-info"><?php echo e($game->publisher); ?></span>
                        <span class="deskripsi"><?php echo e($game->deskripsi); ?></span>
                        <small class="tahun_rilis">Dirilis pada <?php echo e($game->tahun_rilis); ?></small>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\Praetorian 2021 - 2022\Modules\StarOne-laravel\resources\views/games.blade.php ENDPATH**/ ?>