
<?php $__env->startSection('title', 'Manage Game'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 bg-light management-wrapper">
            <h3><i class="uil uil-create-dashboard me-1"></i>Manage Games</h3>
            <p>Manage the games and don't forget to recheck it</p>
            <hr>
            <a href="<?php echo e(url('games/create')); ?>" class="btn btn-dark btn-sm mb-3"><i class="uil uil-plus me-1"></i>Add
                Games</a>
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <i class="uil uil-check-circle me-1"></i><?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <table class="table table-success table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Judul</th>
                        <th>Publisher</th>
                        <th>Deskripsi</th>
                        <th>Tahun Rilis</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $number = 1; ?>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($number++); ?></td>
                            <td><?php echo e($game['judul']); ?></td>
                            <td><?php echo e($game['publisher']); ?></td>
                            <td><?php echo e($game['deskripsi']); ?></td>
                            <td><?php echo e($game['tahun_rilis']); ?></td>
                            <td>
                                <a href="<?php echo e(route('game.edit', $game->id)); ?>" class="text-primary"><i
                                        class="uil uil-edit"></i></a>
                                <a href="#" class="text-danger"
                                    onclick="event.preventDefault();document.getElementById('delete-form-<?php echo e($game->id); ?>').submit();">
                                    <i class="uil uil-trash-alt"></i>
                                    <form id="delete-form-<?php echo e($game->id); ?>"
                                        action="<?php echo e(route('game.delete', $game->id)); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\Praetorian 2021 - 2022\Modules\StarOne-laravel\resources\views/games/index.blade.php ENDPATH**/ ?>