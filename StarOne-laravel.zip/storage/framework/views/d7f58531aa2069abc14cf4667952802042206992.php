

<?php $__env->startSection('title', 'PT StarOne'); ?>

<?php $__env->startSection('content'); ?>
    <!-- BANNER -->
    <div class="container bg-dark banner">
        <h1>Welcome to StarOne</h1>
        <p>Kumpulan informasi game menari hasil karya anak bangsa dan terupdate setiap harinya</p>
        <a href="" class="btn btn-warning">Manage Game</a>
        <a href="" class="btn btn-info">Contact Us</a>
    </div>

    <!-- GAME CONTENT -->
    <div class="container mt-4">
        <div class="row">
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-4">
                    <div class="col-md-12 bg-light game-item">
                        <span class="title"><?php echo e($game->judul); ?></span>
                        <span class="publisher badge bg-info"><?php echo e($game->publisher); ?></span>
                        <span class="deskripsi"><?php echo e($game->deskripsi); ?></span>
                        <small class="tahun_rilis">Dirilis pada <?php echo e($game->tahun_rilis); ?></small>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\Praetorian 2021 - 2022\Modules\StarOne-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>