<h1>Halaman Buku</h1>
<?php /**PATH D:\Sunib\Student Affairs\BNCC\Praetorian 2021 - 2022\Modules\StarOne-laravel\resources\views/books/index.blade.php ENDPATH**/ ?>